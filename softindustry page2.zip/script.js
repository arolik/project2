function inputDep(el) {
  var dep_address = [
    { number: 1, address: "адрес 1 отделения" },
    { number: 2, address: "адрес 2 отделения" },
    { number: 3, address: "адрес 3 отделения" },
    { number: 4, address: "адрес 4 отделения" },
    { number: 5, address: "адрес 5 отделения" },
    { number: 6, address: "адрес 6 отделения" },
  ];
  var item = dep_address.find(i => i.number == el.value);
  if (item)
    document.getElementById("address").value = item.address;
}
function go() {
	var field_surname=document.getElementById('surname').value;
	var field_name=document.getElementById('name').value;
	var field_midname=document.getElementById('midname').value;
	var field_phone=document.getElementById('phone').value;
	var field_city=document.getElementById('city').value;
	var field_departament=document.getElementById('departament').value;
	var field_address=document.getElementById('address').value;
	
	var obj=new Object()
	obj.surname=field_surname;
	obj.name=field_name;
	obj.midname=field_midname;
	obj.phone=field_phone;
	obj.city=field_city;
	obj.departament=field_departament;
	obj.address=field_address;
	console.log(obj)
}